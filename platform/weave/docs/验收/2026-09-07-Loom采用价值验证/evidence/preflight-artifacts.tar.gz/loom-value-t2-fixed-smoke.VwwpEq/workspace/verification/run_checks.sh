#!/bin/sh
set -eu
cd model
python3 -m unittest discover -s tests -v
